#include"holiday.h"

long long int findMaxAttraction(int n, int start, int d, int attraction[]) {
    return 0;
}
