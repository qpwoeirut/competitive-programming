#ifndef __HOLIDAY_H
#define __HOLIDAY_H


long long int findMaxAttraction(int n, int start, int d, int attraction[]) ;
#endif
