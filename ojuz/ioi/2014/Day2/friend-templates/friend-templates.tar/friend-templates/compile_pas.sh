#!/bin/bash

NAME=friend

/usr/bin/fpc -dEVAL -XS -O2 -o$NAME grader.pas
