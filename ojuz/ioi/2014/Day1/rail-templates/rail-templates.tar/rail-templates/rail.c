#include "rail.h"

void findLocation(int N, int first, int location[], int stype[])
{

}
