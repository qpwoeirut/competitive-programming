#ifndef __RAIL_H__
#define __RAIL_H__

#ifdef __cplusplus
extern "C" {
#endif
  void findLocation(int n, int first, int location[], int stype[]);
  
  int getDistance(int i, int j);
#ifdef __cplusplus
}
#endif

#endif /* __RAIL_H__ */

