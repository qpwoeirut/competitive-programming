#include "wall.h"

void buildWall(int n, int k, int op[], int left[], int right[], int height[], int finalHeight[]){
  return;
}

