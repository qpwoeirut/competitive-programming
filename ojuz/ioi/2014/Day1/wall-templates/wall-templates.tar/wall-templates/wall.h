#ifndef _WALL_H
#define _WALL_H

void buildWall(int n, int k, int op[], int left[], int right[], int height[], int finalHeight[]);

#endif
