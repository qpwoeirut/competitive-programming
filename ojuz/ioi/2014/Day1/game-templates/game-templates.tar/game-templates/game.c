#include "game.h"

void initialize(int n) {

}

int hasEdge(int u, int v) {
    return 1;
}
