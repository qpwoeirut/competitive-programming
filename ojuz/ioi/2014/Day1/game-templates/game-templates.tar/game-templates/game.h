#ifndef _GAME_H
#define _GAME_H

void initialize(int n);
int hasEdge(int u, int v);

#endif
